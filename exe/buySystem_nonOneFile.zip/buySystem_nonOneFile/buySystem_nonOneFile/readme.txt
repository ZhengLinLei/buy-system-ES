*******************************************

    *********   ***         ***
    *********   ***         ***
         ***    ***         ***
        ***     ***         ***
       ***      ***         ***
      ***       ***         ***
     ***        ***         ***
    ********    **********  **********
    ********    **********  **********

*******************************************


¡Bienvenidos por primera vez al sistema de pago!

******************************************************************************

--De primero, nuestro sistema esta preparando los datos y las bases de datos, si ve que hay un error por favor cierre y vuelva a descargar.--

Sistema programado por 郑林磊 [Zheng Lin Lei], si a lo largo del uso ocurre errores puede entrar en sección de auto reparación, si persiste el problema puede contactarnos

E-mail : zheng9112003@gmail.com

--------------------------------------------------------------

Descripción del sistema

Añadir-------------

Primero haremos una breve introducción del boton "Añadir" donde abrira un apartado para añadir todo los productos, se localiza en la barra de arriba el primer boton, antes de hacer un cobro deberia de haber un producto añadido

!!! Solo es posible añadir un producto con el mismo codigo de barras, si desea modificar el producto puede seguir leyendo abajo

Ejemplo:

    Codigo barra: 12345678912

    Nombre: Bolsa(pequeña)

    Precio 0.05

Una vez añadido utilice el escaner y haga algunas pruebas de uso, si falla debe ser que el producto no se añadio correctamente





Modificar------------

Si desea modificar o eliminar un producto de la lista, puede darle al segundo boton de la barra superior

Se pueden realizar busquedas del producto por

    Codigo barras(Recomendado， escaneando el codigo)
    Nombre
    Precio

Le aparecera dos botones, "Borrar" y "Modificar". Escoja su acción

Para modificar solo necesita cambiar los parametros.
Y para borrar le da y se eliminara de la base de datos.



Uso------------

Para usar solo necesita acercar el escaner de codigo de barra y se auto completara, cada acción tiene su fastkey(un atajo de teclado como ctrl + v)


    1. Apunta el codigo con la maquina
    2. Una vez autocompletado se da a Enter
    3. Se elige su cantidad y se añadira en el carro
        3.1 Si desea modificar, abajo tiene las acciones

    4. Una vez terminado la compra, se elegira su pago
    5. La compra se guardara en el historial

    -----Si hay un nuevo cliente en el proceso, puede abrir una nueva pestaña





Ver historial de ventas------

El ultimo boton de la barra superior es para realizar vistas del historiar de ventas




Autoreparacion----------

Si ocurre algun problema de uso, puede escoger esta opcion en la barra superior y autoreparara el sistema, si persiste. Puede reparar manualmente.












************************************************************************************


v1.0 2020年

郑林磊 [Zheng Lin Lei]
